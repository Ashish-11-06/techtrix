package com.prushaltech.techtrix;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechtrixApplicationTests {

	@Test
	void contextLoads() {
	}

}
