package com.prushaltech.techtrix.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class QuotationProductResponse {

	private Long quotationProductId;
	private Long quotationId;
	private Long productId;
}
